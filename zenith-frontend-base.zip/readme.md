Ei xera bilolas, essa versão agora inclui:

📱 ZenithFrontendApplication.java (classe principal com @SpringBootApplication)

📱 HomeController.java (rotas home, login, signup)

📱 Templates e arquivos estáticos simulados (HTML, CSS, JS)

📱 Suporte completo a modo claro e escuro (botão 🌙 na navbar)

📱 Estilo visual moderno, com bordas suaves, tipografia limpa e animações leves

📱 pom.xml com o mainClass corretamente declarado (com busta automatica)

📱 iniciar-zenith.bat para rodar o projeto com duplo clique (página de acesso: http://localhost:8080/)