document.getElementById('darkToggle')?.addEventListener('click', () => {
    document.body.classList.toggle('dark');
});